// lettore di file con sintesi vocale
#include <iostream>
#include <windows.h>
#include <string>
#include <fstream>
#include "proto.h"
#include "tasti.h"
#include <sapi.h> // Header SAPI
#include <atlbase.h> // Per COM


using namespace std;

int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        std::cerr << "Usage: lettore nomeFile.estensione" << endl;
        return 1;
    }
    
    int ritardo = 0, nrec = 0;
    std::ifstream file(argv[1]); // Apri il file in lettura
    // Controlla se il file è stato aperto correttamente
    if (file.is_open())
    {
        leggiConfig(&ritardo, &nrec);
        printf("lettore.ini: ritardo %d max records %d\n", ritardo, nrec);
        
        std::string riga;
        int countRec = 0, tasto = 0;
        // Ciclo per leggere il file std::string riga;ga per riga fino alla fine
        while (std::getline(file, riga))
        {
            // Elabora la riga letta mandandola al sintetizzatore vocale

                voce(riga);

            Sleep(ritardo);
            countRec++;
            if (countRec == nrec)
            {
                countRec = 0;
                tasto = attendiTasti();
                if (tasto == ESC)
                {
                    return 0;
                }
                else
                {
                    continue;
                }
            }
        } // fine while
        file.close();
    }
    else
    {
        std::cerr << "Impossibile aprire il file  " << argv[1] << std::endl;
    }

    return 0;
}

void leggiConfig(int *ritardo, int *numrecords)
{

    std::ifstream file("lettore.ini"); // Apri il file in lettura
    if (file.is_open())
    {
        file >> *ritardo;
        file >> *numrecords;
    }
    else
    {
        std::cerr << "Impossibile aprire il file lettore.ini" << std::endl;
    }
    return;
}
// parte della sintesi
// Definizione della funzione per pronunciare la stringa
HRESULT SpeakString(const WCHAR* pszText)
{
    HRESULT hr = S_OK;
    CComPtr<ISpVoice> pVoice; // Puntatore all'interfaccia del sintetizzatore

    // Inizializza l'ambiente COM (necessario per usare SAPI)
    hr = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
    if (FAILED(hr)) {
        std::cerr << "Errore nell'inizializzazione di COM: " << hr << std::endl;
        return hr;
    }

    // Crea l'istanza del sintetizzatore
    hr = pVoice.CoCreateInstance(CLSID_SpVoice);
    if (FAILED(hr)) {
        std::cerr << "Errore nella creazione di IS SpVoice: " << hr << std::endl;
        CoUninitialize();
        return hr;
    }

    // Pronuncia la stringa
    hr = pVoice->Speak(pszText, 0, NULL);
    if (FAILED(hr)) {
        //std::cerr << "Errore durante la pronuncia: " << hr << std::endl;
    }

    // Disattiva l'ambiente COM
    CoUninitialize();
    return hr;
}

int voce(std::string stringaInput)
{
    std::string textToSpeak_str = stringaInput;
    std::wstring textToSpeak(textToSpeak_str.begin(), textToSpeak_str.end());

    // Chiama la funzione per pronunciare la stringa
    HRESULT hr = SpeakString(textToSpeak.c_str());

    if (FAILED(hr)) {
        return 1; // Errore nella sintesi
    }

    return 0; // Successo
}

// da fare taglia e cuci
