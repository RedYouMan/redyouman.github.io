#ifndef PROTO
#define PROTO

int voce(std::string str);
void leggiConfig(int *rit, int *rec);
#endif